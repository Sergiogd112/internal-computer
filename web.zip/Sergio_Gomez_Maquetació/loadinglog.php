<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>loading</title>
    <link rel="stylesheet" href="css/loading.css">

  </head>
  <body>
<div class="main">
<div class="loader">

</div>
<p>Loading</p>
</div>
<?php
$lname=$_POST["logname"];
$pss=$_POST["password"];
$servername = "localhost";
$usr = "sgomez";
$pass = "sgomez";
$dbname = "sgomez_";



// Create connection
$conn = new mysqli($servername, $usr, $pass, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "SELECT * FROM user_data WHERE username='$lname' OR email='$lname'";
echo $sql;
$result = $conn->query($sql);
echo $res;
if($res = mysqli_query($link, $sql)){
   if(mysqli_num_rows($res) > 0){
       echo "<table>";
           echo "<tr>";
               echo "<th>Firstname</th>";
               echo "<th>Lastname</th>";
               echo "<th>age</th>";
           echo "</tr>";
       while($row = mysqli_fetch_array($res)){
           echo "<tr>";
               echo "<td>" . $row['name'] . "</td>";
               echo "<td>" . $row['surname'] . "</td>";
               echo "<td>" . $row['email'] . "</td>";
           echo "</tr>";
       }
       echo "</table>";
       mysqli_free_result($res);
   } else{
     echo "nothing";
}
} else{
   echo "ERROR: Could not able to execute $sql. "
                               . mysqli_error($link);
}

echo "done";

 ?>

  </body>
</html>
