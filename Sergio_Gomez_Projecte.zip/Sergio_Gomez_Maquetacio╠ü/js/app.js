function load() {
  var xhttp= new XMLHttpRequest();
  xhttp.onreadystatechange = function(){
    if(this.readyState == 4 && this.status ==200){
      function process(this.responseText);
      console.log(this.responseText);

    }
  }
}
function process(txt) {
  return txt;
}
