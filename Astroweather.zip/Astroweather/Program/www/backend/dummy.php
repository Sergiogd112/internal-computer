<?php
echo shell_exec("/usr/bin/python3 /home/sgomez/internal-computer/Sergio_Gomez_Maquetació/backend/mailer.py astroweathercs@gmail.com eR21dEGPHpnU smtp.gmail.com [astroweathercs@gmail.com,] 'Contact Astroweather CS' 'help me
pleaaaasse
pleassse work' []")
 ?>
