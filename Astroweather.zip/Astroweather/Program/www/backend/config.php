<?php
$dbpass="astroweather";
$dbuser="astroweather";
$dbname="astroweather";
$servername="db";
 ?>
