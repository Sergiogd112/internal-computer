<?php
function loaded(){
  echo "test";
}
 ?>
